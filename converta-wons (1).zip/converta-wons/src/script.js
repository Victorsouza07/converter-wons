valorwons = prompt("digte um valo em wons")
wons = 0.0040
alert("O valor convertido em reais é: R$ " + valorwons * wons + "milhões")